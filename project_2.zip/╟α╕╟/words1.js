var words = [
	 "dragon", "birthday","apple","bottle"
	  ];